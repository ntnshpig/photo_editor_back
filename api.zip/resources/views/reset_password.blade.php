<main>
    Hello, {{$login}}!<br><br>
    We noticed that someone tried to reset your password!<br>
    If it was you then go to the link below<br><br>
    Your link is: {{$link}}<br>
</main>